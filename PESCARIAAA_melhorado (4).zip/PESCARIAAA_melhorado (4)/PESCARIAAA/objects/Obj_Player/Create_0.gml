sistema_garantir();

hspd = 0;     // velocidade horizontal
spd = 7;      // multiplicador de velocidade
