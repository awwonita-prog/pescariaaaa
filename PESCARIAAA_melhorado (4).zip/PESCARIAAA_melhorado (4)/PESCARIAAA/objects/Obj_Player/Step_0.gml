if (jogo_parado()) {
    image_speed = 0;
    exit;
}
image_speed = 1;

// ANDAR (A/D ou setas) - sem keyboard_set_map
var _esq = keyboard_check(vk_left) || keyboard_check(ord("A"));
var _dir = keyboard_check(vk_right) || keyboard_check(ord("D"));
move = _dir - _esq;
hspd = move * spd;

// COLISÃO
if (place_meeting(x + hspd, y, Obj_block)) {
    while (!place_meeting(x + sign(hspd), y, Obj_block)) {
        x += sign(hspd);
    }
    hspd = 0;
}
x += hspd;

// TROCA DE SPRITE / INVERSÃO DA DIREÇÃO
if (hspd != 0) {
    sprite_index = Spr_Player_Walk;
    image_xscale = sign(hspd);
} else {
    sprite_index = Spr_Player_Idle;
}
