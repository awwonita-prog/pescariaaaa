// ======================== FICHA DO PEIXE ========================
// Sprite = campo Sprite do objeto. Movimento = objeto PAI (Obj_Fish_Straight).
// Novo peixe? Duplique este objeto e cadastre em Scr_Catalogo (especies_cadastradas).
nome            = "Salmão";
descricao       = "Nada sem parar contra a correnteza, sempre pelo mesmo caminho.";
curiosidade     = "Ele sempre volta ao lugar onde nasceu. Alguns voltam diferentes.";
raridade        = RARIDADE.COMUM;   // COMUM, INCOMUM, RARO ou LENDARIO
pontos          = 10;
velocidade      = 2.8;
escala          = 1.0;
cor             = make_color_rgb(250, 140, 120);   // tinta do sprite (c_white = sem tinta)
prof_min        = 150;
prof_max        = 1300;
esvazia         = 0.9;    // barra esvazia por frame
clique          = 18;     // cada clique enche a barra  (~3.0 cliques/s para empatar, na fase 1)
fases           = [1, 2];
alcance         = 420;     // (opcional) pixels que ele nada antes de voltar
// ================================================================

event_inherited();
