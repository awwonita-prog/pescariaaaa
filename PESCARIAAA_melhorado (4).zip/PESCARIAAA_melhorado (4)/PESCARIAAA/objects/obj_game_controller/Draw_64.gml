// ---------- FINAL: tela preta com a notícia ----------
if (estado == FASE_ESTADO.FINAL) {
    draw_set_color(c_black);
    draw_set_alpha(clamp(tempo_final / 150, 0, 1));
    draw_rectangle(0, 0, GUI_W, GUI_H, false);
    draw_set_alpha(1);

    var _y = 130;
    for (var i = 0; i < array_length(final_linhas); i++) {
        var _linha = final_linhas[i];
        var _esc = 1.5;
        var _cor = c_ltgray;
        var _alt = 36;
        if (i == 0) { _esc = 1.2; _cor = c_gray;  _alt = 44; }      // nome do jornal
        else if (i == 1) { _esc = 2.0; _cor = c_white; _alt = 56; } // manchete
        if (_linha == "") _alt = 20;

        var _a = clamp((tempo_final - final_inicio[i]) / 45, 0, 1);
        if (_a > 0 && _linha != "") {
            draw_set_alpha(_a);
            ui_texto(GUI_W / 2, _y, _linha, _cor, _esc, fa_center, fa_top);
            draw_set_alpha(1);
        }
        _y += _alt;
    }

    if (tempo_final > final_duracao) {
        draw_set_alpha(0.5 + 0.5 * sin(tempo_final * 0.08));
        ui_texto(GUI_W / 2, GUI_H - 60, "ENTER: voltar ao menu", c_gray, 1.3, fa_center, fa_middle);
        draw_set_alpha(1);
    }
    draw_set_color(c_white);
    exit;
}

var _cam_y = camera_get_view_y(view_camera[0]);

// ---- escuridão: cresce com a fase e com a profundidade ----
var _escuro = fase.escuridao + (_cam_y / room_height) * 0.4 + sin(tempo * 0.03) * 0.03;
if (_escuro > 0.01) {
    draw_set_color(c_black);
    draw_set_alpha(clamp(_escuro, 0, 0.65));
    draw_rectangle(0, 0, GUI_W, GUI_H, false);
    draw_set_alpha(1);
}

// ---- painel da fase (canto superior esquerdo) ----
ui_painel(12, 10, 330, 124, 0.55);
ui_texto(24, 18, "FASE " + string(global.fase_atual + 1) + "/" + string(fase_total()) + "  " + fase.nome, c_white, 1.2);
ui_texto(24, 46, "Peixes: " + string(peixes_pegos) + "/" + string(fase.meta), c_white, 1.2);
ui_barra(24, 74, 294, 12, peixes_pegos / fase.meta, c_white);
ui_texto(24, 94, "Pontos: " + string(global.pontos), c_ltgray, 1.2);

// ---- profundidade (canto superior direito) ----
ui_texto(GUI_W - 24, 18, "Profundidade: " + string(floor((_cam_y + GUI_H / 2) / 10)) + " m", c_gray, 1.2, fa_right);

// ---- última fase: indica para onde olhar (o único peixe fica no escuro) ----
if (global.fase_atual == fase_total() - 1 && estado == FASE_ESTADO.JOGANDO && instance_exists(Obj_Fish)) {
    var _alvo = instance_find(Obj_Fish, 0);
    draw_set_alpha(0.45 + 0.45 * sin(tempo * 0.08));
    if (_alvo.y > _cam_y + GUI_H) {
        ui_texto(GUI_W / 2, GUI_H - 70, "v   mais fundo   v", c_white, 1.6, fa_center, fa_middle);
    } else if (_alvo.y < _cam_y) {
        ui_texto(GUI_W / 2, 150, "^   mais acima   ^", c_white, 1.6, fa_center, fa_middle);
    }
    draw_set_alpha(1);
}

// ---- barra de pesca ----
if (fishing && instance_exists(current_fish)) {
    var _bw = 380;
    var _bx = (GUI_W - _bw) / 2;
    var _pct = fishing_bar / bar_max;
    var _cor = (_pct < 0.25) ? c_red : c_white;
    ui_texto(GUI_W / 2, 26, current_fish.nome, raridade_cor(current_fish.raridade), 1.5, fa_center, fa_middle);
    ui_barra(_bx, 46, _bw, 24, _pct, _cor);
    ui_texto(GUI_W / 2, 86, "Clique rápido!", c_gray, 1.2, fa_center, fa_middle);
}

// ---- textos flutuantes ----
for (var i = 0; i < array_length(popups); i++) {
    var _p = popups[i];
    draw_set_alpha(clamp(_p.vida / 30, 0, 1));
    ui_texto(_p.x, _p.y - _cam_y, _p.txt, _p.cor, 1.5, fa_center, fa_middle);
    draw_set_alpha(1);
}

// ---- dicas iniciais ----
if (tempo < 900 && estado == FASE_ESTADO.JOGANDO) {
    draw_set_alpha(clamp((900 - tempo) / 120, 0, 1));
    ui_texto(GUI_W / 2, GUI_H - 28, "Leve o anzol até o peixe e clique nele   |   Roda do mouse ou W/S: descer e subir   |   TAB: catálogo   |   ESC: pausa", c_gray, 1.1, fa_center, fa_middle);
    draw_set_alpha(1);
}

// ---- fase concluída ----
if (estado == FASE_ESTADO.CONCLUIDA || estado == FASE_ESTADO.TRANSICAO) {
    draw_set_color(c_black);
    draw_set_alpha(0.7);
    draw_rectangle(0, GUI_H / 2 - 90, GUI_W, GUI_H / 2 + 90, false);
    draw_set_alpha(1);
    ui_texto(GUI_W / 2, GUI_H / 2 - 30, "FASE COMPLETA!", c_white, 3.5, fa_center, fa_middle);
    ui_texto(GUI_W / 2, GUI_H / 2 + 40, "Peixes: " + string(peixes_pegos) + "     Pontos da fase: " + string(pontos_fase), c_gray, 1.6, fa_center, fa_middle);
}
draw_set_color(c_white);
