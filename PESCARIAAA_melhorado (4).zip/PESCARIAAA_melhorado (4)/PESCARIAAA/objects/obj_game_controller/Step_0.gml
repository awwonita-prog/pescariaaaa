if (jogo_parado()) exit;
tempo++;

// textos flutuantes
for (var i = array_length(popups) - 1; i >= 0; i--) {
    popups[i].y -= 0.6;
    popups[i].vida -= 1;
    if (popups[i].vida <= 0) array_delete(popups, i, 1);
}

switch (estado) {
    case FASE_ESTADO.JOGANDO:
        if (fishing) pesca_atualizar();

        spawn_timer--;
        if (spawn_timer <= 0) {
            spawn_timer = fase.intervalo;
            if (instance_number(Obj_Fish) < fase.max_vivos) fase_spawnar_peixe();
        }
        break;

    case FASE_ESTADO.CONCLUIDA:
        timer_conclusao--;
        if (timer_conclusao <= 0) fase_avancar();
        break;

    case FASE_ESTADO.FINAL:
        tempo_final++;
        // só aceita sair depois que a notícia terminou de aparecer
        if (tempo_final > final_duracao && (keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space)
            || keyboard_check_pressed(vk_escape) || mouse_check_button_pressed(mb_left))) {
            estado = FASE_ESTADO.TRANSICAO;
            transicao_para(MenuInicial, "", "");
        }
        break;
}
