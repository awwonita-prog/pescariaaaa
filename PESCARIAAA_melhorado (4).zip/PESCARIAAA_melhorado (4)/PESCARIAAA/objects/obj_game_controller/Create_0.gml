// Controlador da room Mar: pesca, meta da fase, HUD, spawn e final do jogo.
// (Não é mais persistente: o que precisa durar vive em global.*)
jogo_garantir_init();
sistema_garantir();

fase = fase_atual_dados();
estado = FASE_ESTADO.JOGANDO;
peixes_pegos = 0;          // peixes pescados nesta fase
pontos_fase = 0;
tempo = 0;
spawn_timer = fase.intervalo;
timer_conclusao = 0;
popups = [];
global.sem_pausa = false;

// --- final do jogo (notícia na tela preta) ---
final_linhas = [];
final_inicio = [];         // frame em que cada linha começa a aparecer
final_duracao = 0;
tempo_final = 0;

// --- estado da pesca (nomes mantidos da versão original) ---
fishing = false;
current_fish = noone;
fishing_bar = 0;
bar_max = BARRA_MAX;
carencia_clique = 0;       // o clique que fisga o peixe não conta para a barra

/// texto flutuante em coordenadas da room
popup_criar = function(_x, _y, _txt, _cor) {
    array_push(popups, { x: _x, y: _y, txt: _txt, cor: _cor, vida: 70 });
};

/// chamado pelo peixe (Mouse_4). Devolve true se começou a pesca.
pesca_iniciar = function(_peixe) {
    if (estado != FASE_ESTADO.JOGANDO || fishing) return false;
    fishing = true;
    current_fish = _peixe;
    fishing_bar = BARRA_INICIAL;
    carencia_clique = 1;
    _peixe.being_caught = true;
    return true;
};

pesca_atualizar = function() {
    if (!instance_exists(current_fish)) {
        fishing = false;
        current_fish = noone;
        exit;
    }

    fishing_bar -= current_fish.difficulty_decay;
    if (carencia_clique > 0) {
        carencia_clique--;
    } else if (mouse_check_button_pressed(mb_left)) {
        fishing_bar += current_fish.difficulty_gain;
    }
    fishing_bar = clamp(fishing_bar, 0, bar_max);

    if (fishing_bar >= bar_max) {
        peixe_capturar(current_fish);
    } else if (fishing_bar <= 0) {
        popup_criar(current_fish.x, current_fish.y - 40, "Escapou!", c_gray);
        with (current_fish) escapar();
        fishing = false;
        current_fish = noone;
    }
};

peixe_capturar = function(_peixe) {
    var _esp = _peixe.especie;          // struct do catálogo (pode ser undefined se o peixe não está cadastrado)
    var _pts = _peixe.fish_value;
    var _novo = (_esp != undefined) && !_esp.descoberto;

    global.pontos += _pts;
    pontos_fase += _pts;
    global.peixes_total += 1;
    peixes_pegos += 1;
    if (_esp != undefined) catalogo_registrar_captura(_esp);

    popup_criar(_peixe.x, _peixe.y - 40, "+" + string(_pts) + "  " + _peixe.nome, c_white);
    if (_novo) popup_criar(_peixe.x, _peixe.y - 72, "NOVO NO CATÁLOGO!", c_yellow);

    instance_destroy(_peixe);
    fishing = false;
    current_fish = noone;
    save_gravar();

    if (peixes_pegos >= fase.meta) fase_concluir();
};

fase_concluir = function() {
    global.sem_pausa = true;
    global.melhor_pontos = max(global.melhor_pontos, global.pontos);
    global.fase_maxima = max(global.fase_maxima, global.fase_atual + 1);
    save_gravar();

    if (global.fase_atual + 1 >= fase_total()) {
        // meta da última fase cumprida: fim de jogo
        final_preparar();
        estado = FASE_ESTADO.FINAL;
    } else {
        estado = FASE_ESTADO.CONCLUIDA;
        timer_conclusao = 150;
    }
};

fase_avancar = function() {
    global.fase_atual += 1;
    estado = FASE_ESTADO.TRANSICAO;
    transicao_para_fase(global.fase_atual);
};

/// calcula quando cada linha da notícia começa a aparecer
final_preparar = function() {
    final_linhas = final_noticia();
    final_inicio = [];
    var _t = 220;                       // a tela escurece antes da 1ª linha
    for (var i = 0; i < array_length(final_linhas); i++) {
        array_push(final_inicio, _t);
        _t += (final_linhas[i] == "") ? 25 : 75;
    }
    final_duracao = _t + 90;            // depois disso aparece "ENTER: voltar ao menu"
    tempo_final = 0;
};

// população inicial
repeat (fase.max_vivos) fase_spawnar_peixe();
