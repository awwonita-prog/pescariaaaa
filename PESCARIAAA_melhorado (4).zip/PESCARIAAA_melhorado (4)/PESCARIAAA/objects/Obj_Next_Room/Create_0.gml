perto = false;
