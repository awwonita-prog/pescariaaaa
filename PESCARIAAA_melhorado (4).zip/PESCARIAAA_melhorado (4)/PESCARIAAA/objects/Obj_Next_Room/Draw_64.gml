// Dica na tela (a room Barco usa a view inteira, então room = GUI)
if (perto && !global.pausado && !transicao_bloqueia()) {
    ui_texto(x + 32, y - 28, "[ESPAÇO] Pescar", c_white, 1.5, fa_center, fa_middle);
}
