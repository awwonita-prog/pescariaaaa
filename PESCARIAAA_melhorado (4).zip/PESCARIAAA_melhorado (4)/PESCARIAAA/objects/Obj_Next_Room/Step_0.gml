// Pressione ESPAÇO perto da vara para começar a pescar
if (jogo_parado()) exit;

perto = place_meeting(x, y, Obj_Player);

if (perto && keyboard_check_pressed(vk_space)) {
    transicao_para_fase(global.fase_atual);
}
