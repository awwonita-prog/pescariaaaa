// ======================== FICHA DO PEIXE ========================
// Sprite = campo Sprite do objeto. Movimento = objeto PAI (Obj_Fish_Wander).
// Novo peixe? Duplique este objeto e cadastre em Scr_Catalogo (especies_cadastradas).
nome            = "Tubarão-tigre";
descricao       = "Devora qualquer coisa. Nada firme e briga com força.";
curiosidade     = "Já acharam placa de carro e pneu na barriga de um. Nada é estranho demais para ele.";
raridade        = RARIDADE.RARO;   // COMUM, INCOMUM, RARO ou LENDARIO
pontos          = 75;
velocidade      = 2.0;
escala          = 1.8;
cor             = make_color_rgb(150, 150, 130);   // tinta do sprite (c_white = sem tinta)
prof_min        = 1200;
prof_max        = 2800;
esvazia         = 1.15;    // barra esvazia por frame
clique          = 15;     // cada clique enche a barra  (~4.6 cliques/s para empatar, na fase 1)
fases           = [4, 5];
fuga_distancia  = 80;     // (opcional) a que distância do anzol ele começa a fugir
fuga_velocidade = 1.9;    // (opcional) multiplicador da velocidade ao fugir
// ================================================================

event_inherited();
