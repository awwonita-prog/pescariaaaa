if (jogo_parado()) exit;

if (mouse_wheel_up()) alvo_y -= velocidade_roda;
if (mouse_wheel_down()) alvo_y += velocidade_roda;
if (keyboard_check(vk_up) || keyboard_check(ord("W"))) alvo_y -= velocidade_tecla;
if (keyboard_check(vk_down) || keyboard_check(ord("S"))) alvo_y += velocidade_tecla;

alvo_y = clamp(alvo_y, 0, room_height - camera_get_view_height(cam));

var _y = lerp(camera_get_view_y(cam), alvo_y, suavizacao);
camera_set_view_pos(cam, camera_get_view_x(cam), _y);
