// Câmera vertical do mar: roda do mouse (ou W/S, setas) desce e sobe.
cam = view_camera[0];
velocidade_roda = 120;      // pixels por "clique" da roda
velocidade_tecla = 14;      // pixels por frame com W/S
suavizacao = 0.12;
alvo_y = camera_get_view_y(cam);
