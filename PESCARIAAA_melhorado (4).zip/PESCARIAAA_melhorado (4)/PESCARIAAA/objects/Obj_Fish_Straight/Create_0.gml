event_inherited();

// campo opcional da ficha: alcance = quantos pixels vai antes de voltar
peixe_padrao("alcance", random_range(150, 260));

dir_horizontal = choose(-1, 1);
start_x = x;
travel_range = alcance;

// ao escapar, o novo "ponto de partida" é onde ele está
fish_init_movement = function() {
    start_x = x;
};
fish_init_movement();
