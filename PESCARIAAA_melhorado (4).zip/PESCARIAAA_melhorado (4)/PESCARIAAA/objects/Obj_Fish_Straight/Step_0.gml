event_inherited();
if (parado) exit;

x += spd * dir_horizontal;
image_angle = 0;
image_xscale = escala * dir_horizontal;
image_yscale = escala;

// vai e volta no trajeto; também vira se for em direção à parede do mar
if (abs(x - start_x) >= travel_range) dir_horizontal *= -1;
if ((x <= 0 && dir_horizontal < 0) || (x >= room_width && dir_horizontal > 0)) dir_horizontal *= -1;
x = clamp(x, 0, room_width);
