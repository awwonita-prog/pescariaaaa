// ======================== FICHA DO PEIXE ========================
// Sprite = campo Sprite do objeto. Movimento = objeto PAI (Obj_Fish_Wander).
// Novo peixe? Duplique este objeto e cadastre em Scr_Catalogo (especies_cadastradas).
nome            = "Tubarão-branco";
descricao       = "O grande predador. Quase não foge, mas a briga é pesada.";
curiosidade     = "Ele não foge de nada. Ele vem até você.";
raridade        = RARIDADE.LENDARIO;   // COMUM, INCOMUM, RARO ou LENDARIO
pontos          = 150;
velocidade      = 2.4;
escala          = 2.4;
cor             = make_color_rgb(225, 225, 230);   // tinta do sprite (c_white = sem tinta)
prof_min        = 2000;
prof_max        = 3800;
esvazia         = 1.3;    // barra esvazia por frame
clique          = 14;     // cada clique enche a barra  (~5.6 cliques/s para empatar, na fase 1)
fases           = [5];
fuga_distancia  = 40;     // (opcional) a que distância do anzol ele começa a fugir
fuga_velocidade = 1.4;    // (opcional) multiplicador da velocidade ao fugir
// ================================================================

event_inherited();
