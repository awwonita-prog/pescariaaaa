// ======================== FICHA DO PEIXE ========================
// Sprite = campo Sprite do objeto. Movimento = objeto PAI (Obj_Fish_Wander).
// Novo peixe? Duplique este objeto e cadastre em Scr_Catalogo (especies_cadastradas).
nome            = "Peixe-leão";
descricao       = "Cheio de espinhos venenosos, mas lento e sem medo de ninguém.";
curiosidade     = "Aqui ele não tem predadores. Pergunte-se por quê.";
raridade        = RARIDADE.INCOMUM;   // COMUM, INCOMUM, RARO ou LENDARIO
pontos          = 22;
velocidade      = 1.0;
escala          = 0.9;
cor             = make_color_rgb(230, 90, 60);   // tinta do sprite (c_white = sem tinta)
prof_min        = 600;
prof_max        = 1700;
esvazia         = 0.8;    // barra esvazia por frame
clique          = 18;     // cada clique enche a barra  (~2.7 cliques/s para empatar, na fase 1)
fases           = [2, 3];
fuga_distancia  = 45;     // (opcional) a que distância do anzol ele começa a fugir
fuga_velocidade = 1.3;    // (opcional) multiplicador da velocidade ao fugir
// ================================================================

event_inherited();
