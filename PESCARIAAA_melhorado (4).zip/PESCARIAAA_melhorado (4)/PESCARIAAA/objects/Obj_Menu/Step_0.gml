if (transicao_bloqueia()) exit;

var _ev = menu.atualizar();

if (tela == "principal") {
    switch (_ev) {
        case "jogar":
            jogo_novo();
            transicao_para(Barco, "PESCARIA", "Prepare a vara. O mar está esperando.");
            break;
        case "catalogo":
            transicao_para(Catalogo, "", "");
            break;
        case "opcoes":
            tela = "opcoes";
            menu = menu_opcoes_criar(GUI_W / 2, 360);
            break;
        case "sair":
            save_gravar();
            game_end();
            break;
    }
} else {
    menu_opcoes_processar(menu, _ev);
    if (_ev == "voltar" || keyboard_check_pressed(vk_escape)) {
        save_gravar();
        tela = "principal";
        menu = menu_principal_criar();
    }
}
