jogo_garantir_init();
sistema_garantir();

tela = "principal";                 // "principal" ou "opcoes"
menu = menu_principal_criar();
