// escurece um pouco o cenário para o texto aparecer bem
draw_set_color(c_black);
draw_set_alpha(0.5);
draw_rectangle(0, 0, GUI_W, GUI_H, false);
draw_set_alpha(1);

ui_titulo(GUI_W / 2, 150, "KITTY TALES", 1.7);
ui_texto(GUI_W / 2, 235, "quando você olhar por muito tempo para o abismo, o abismo também olhará para você", c_gray, 1.5, fa_center, fa_middle);

if (tela == "opcoes") {
    ui_texto(GUI_W / 2, 300, "Opções", c_white, 2.2, fa_center, fa_middle);
}
menu.desenhar();

var _rodape = "Melhor pontuação: " + string(global.melhor_pontos)
    + "     Fase mais distante: " + string(global.fase_maxima) + "/" + string(fase_total())
    + "     Catálogo: " + string(catalogo_total_descobertos()) + "/" + string(catalogo_total());
ui_texto(GUI_W / 2, GUI_H - 50, _rodape, c_gray, 1.3, fa_center, fa_middle);
