var _total = catalogo_total();

// fundo
draw_set_color(c_black);
draw_set_alpha(modo_sala ? 1 : 0.88);
draw_rectangle(0, 0, GUI_W, GUI_H, false);
draw_set_alpha(1);

ui_texto(GUI_W / 2, 48, "Catálogo de Peixes", c_white, 2.6, fa_center, fa_middle);
ui_texto(GUI_W - 60, 48, "Descobertos: " + string(catalogo_total_descobertos()) + "/" + string(_total), c_gray, 1.5, fa_right, fa_middle);

// ---- cards da página atual ----
var _pagina = sel div por_pagina;
var _ini = _pagina * por_pagina;
for (var i = _ini; i < min(_ini + por_pagina, _total); i++) {
    var _e = global.especies[i];
    var _cx = card_x(i);
    var _cy = card_y(i);

    draw_set_color(make_color_rgb(30, 34, 42));
    draw_rectangle(_cx, _cy, _cx + card_w, _cy + card_h, false);
    draw_set_color((i == sel) ? c_white : c_dkgray);
    draw_rectangle(_cx, _cy, _cx + card_w, _cy + card_h, true);
    if (i == sel) draw_rectangle(_cx + 1, _cy + 1, _cx + card_w - 1, _cy + card_h - 1, true);

    var _cor = _e.descoberto ? _e.cor : c_black;   // silhueta se ainda não descoberto
    ui_sprite_centrado(_e.sprite, 0, _cx + card_w / 2, _cy + 52, _e.escala * 0.9, _cor);

    var _nome = _e.descoberto ? _e.nome : "???";
    ui_texto(_cx + card_w / 2, _cy + card_h - 20, _nome, _e.descoberto ? raridade_cor(_e.raridade) : c_gray, 1.3, fa_center, fa_middle);
    if (!_e.descoberto) ui_texto(_cx + card_w / 2, _cy + 52, "?", c_gray, 3, fa_center, fa_middle);
}

// ---- painel de detalhes ----
var _px1 = (GUI_W - (colunas * card_w + (colunas - 1) * card_gap)) / 2;
var _px2 = GUI_W - _px1;
var _py1 = 400;
var _py2 = GUI_H - 90;
ui_painel(_px1, _py1, _px2, _py2, 0.6);

var _s = global.especies[sel];
ui_sprite_centrado(_s.sprite, 0, _px1 + 130, (_py1 + _py2) / 2, _s.escala * 1.8, _s.descoberto ? _s.cor : c_black);

var _tx = _px1 + 270;
var _tw = _px2 - _tx - 24;
if (_s.descoberto) {
    ui_texto(_tx, _py1 + 16, _s.nome, c_white, 2.2);
    ui_texto(_tx, _py1 + 60, raridade_nome(_s.raridade), raridade_cor(_s.raridade), 1.5);
    ui_texto(_tx + 200, _py1 + 60, string(_s.pontos) + " pontos", c_white, 1.5);
    ui_texto(_tx + 400, _py1 + 60, "Capturados: " + string(_s.capturas), c_white, 1.5);
    ui_texto(_tx, _py1 + 92, "Profundidade: " + string(floor(_s.prof_min / 10)) + " a " + string(floor(_s.prof_max / 10)) + " m", c_gray, 1.3);
    ui_texto_quebra(_tx, _py1 + 126, _s.descricao, c_white, 1.3, _tw);
    ui_texto_quebra(_tx, _py1 + 186, "\"" + _s.curiosidade + "\"", c_gray, 1.2, _tw);
} else {
    ui_texto(_tx, _py1 + 16, "???", c_gray, 2.2);
    ui_texto(_tx, _py1 + 70, "Espécie desconhecida.", c_gray, 1.4);
    ui_texto(_tx, _py1 + 100, "Pesque este peixe para revelar o que ele esconde.", c_gray, 1.3);
}

// ---- rodapé ----
if (_total > por_pagina) {
    ui_texto(GUI_W / 2, GUI_H - 100, "Página " + string(_pagina + 1) + "/" + string(ceil(_total / por_pagina)), c_gray, 1.1, fa_center, fa_middle);
}
var _bx1 = GUI_W / 2 - 120;
var _by1 = GUI_H - 72;
ui_painel(_bx1, _by1, _bx1 + 240, _by1 + 44, 0.6);
ui_texto(GUI_W / 2, _by1 + 22, "Voltar (ESC)", c_white, 1.5, fa_center, fa_middle);
ui_texto(GUI_W - 40, GUI_H - 28, "Setas/mouse: escolher", c_gray, 1.0, fa_right, fa_middle);
draw_set_color(c_white);
