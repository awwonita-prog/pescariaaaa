// Catálogo de peixes. Funciona de dois jeitos:
//  - modo_sala: é a room "Catalogo" (vindo do menu principal)
//  - overlay:   criado por cima do jogo (TAB ou menu de pausa)
jogo_garantir_init();
sistema_garantir();

modo_sala = (room == Catalogo);
pausado_antes = global.pausado;
if (!modo_sala) global.pausado = true;

sel = 0;                 // espécie selecionada (índice)
colunas = 4;
por_pagina = 8;
card_w = 240;
card_h = 130;
card_gap = 20;
bloqueio = 2;            // ignora cliques nos primeiros frames
mx_ant = -1;
my_ant = -1;

/// posição do card de índice _i na página atual
card_x = function(_i) {
    var _x0 = (GUI_W - (colunas * card_w + (colunas - 1) * card_gap)) / 2;
    return _x0 + (_i mod por_pagina mod colunas) * (card_w + card_gap);
};
card_y = function(_i) {
    return 110 + ((_i mod por_pagina) div colunas) * (card_h + card_gap);
};

fechar = function() {
    global.ignorar_teclas = true;
    if (modo_sala) {
        transicao_para(MenuInicial, "", "");
    } else {
        global.pausado = pausado_antes;
        instance_destroy();
    }
};
