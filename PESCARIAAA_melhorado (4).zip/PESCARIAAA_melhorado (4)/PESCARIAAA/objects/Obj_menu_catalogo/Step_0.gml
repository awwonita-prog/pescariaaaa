if (bloqueio > 0) {
    bloqueio--;
    exit;
}
if (transicao_bloqueia()) exit;

var _total = catalogo_total();

// navegação por teclado
if (keyboard_check_pressed(vk_right) || keyboard_check_pressed(ord("D"))) sel = min(sel + 1, _total - 1);
if (keyboard_check_pressed(vk_left) || keyboard_check_pressed(ord("A"))) sel = max(sel - 1, 0);
if (keyboard_check_pressed(vk_down) || keyboard_check_pressed(ord("S"))) sel = min(sel + colunas, _total - 1);
if (keyboard_check_pressed(vk_up) || keyboard_check_pressed(ord("W"))) sel = max(sel - colunas, 0);

// mouse: passar por cima seleciona, clicar também
var _mx = device_mouse_x_to_gui(0);
var _my = device_mouse_y_to_gui(0);
var _clique = mouse_check_button_pressed(mb_left);
var _pagina = sel div por_pagina;
var _ini = _pagina * por_pagina;
for (var i = _ini; i < min(_ini + por_pagina, _total); i++) {
    if (point_in_rectangle(_mx, _my, card_x(i), card_y(i), card_x(i) + card_w, card_y(i) + card_h)) {
        if (_mx != mx_ant || _my != my_ant || _clique) sel = i;
    }
}
mx_ant = _mx;
my_ant = _my;

// botão Voltar
var _bx1 = GUI_W / 2 - 120;
var _by1 = GUI_H - 72;
if (_clique && point_in_rectangle(_mx, _my, _bx1, _by1, _bx1 + 240, _by1 + 44)) {
    fechar();
    exit;
}

if (keyboard_check_pressed(vk_escape) || keyboard_check_pressed(vk_tab) || keyboard_check_pressed(vk_backspace)) {
    fechar();
}
