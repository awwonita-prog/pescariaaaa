// Parte comum a todos os peixes. Os filhos chamam event_inherited() e
// depois fazem "if (parado) exit;" antes de se mover.
var _congelado = jogo_parado();
parado = (being_caught || _congelado);
image_speed = _congelado ? 0 : 1;
if (cooldown_fisgar > 0 && !_congelado) cooldown_fisgar--;
