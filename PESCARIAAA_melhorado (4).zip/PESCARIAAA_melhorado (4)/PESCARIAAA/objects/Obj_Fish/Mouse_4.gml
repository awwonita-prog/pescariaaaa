// Clique no peixe: só fisga se o ANZOL estiver perto dele.
if (jogo_parado() || being_caught || cooldown_fisgar > 0) exit;
if (!instance_exists(obj_game_controller) || !instance_exists(Obj_Hook)) exit;

if (point_distance(x, y, Obj_Hook.x, Obj_Hook.y) > RAIO_FISGAR * max(1, escala)) {
    with (obj_game_controller) {
        if (!fishing) popup_criar(other.x, other.y - 40, "Aproxime o anzol!", c_gray);
    }
    exit;
}

with (obj_game_controller) {
    pesca_iniciar(other.id);
}
