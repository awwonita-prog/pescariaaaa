// Peixe fisgado treme enquanto você puxa a linha
var _dx = 0;
var _dy = 0;
if (being_caught && !global.pausado) {
    _dx = random_range(-3, 3);
    _dy = random_range(-3, 3);
}
draw_sprite_ext(sprite_index, image_index, x + _dx, y + _dy, image_xscale, image_yscale, image_angle, image_blend, image_alpha);
