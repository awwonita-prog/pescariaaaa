// Pai de todos os peixes. Lê a FICHA definida no Create do objeto filho
// (variáveis atribuídas ANTES do event_inherited()) e preenche o que faltar.

// ---------- ficha (valores padrão para campos omitidos) ----------
peixe_padrao("nome", object_get_name(object_index));
peixe_padrao("descricao", "");
peixe_padrao("curiosidade", "");
peixe_padrao("raridade", RARIDADE.COMUM);
peixe_padrao("pontos", 10);
peixe_padrao("velocidade", 2.5);
peixe_padrao("escala", 1);
peixe_padrao("cor", c_white);
peixe_padrao("prof_min", 150);
peixe_padrao("prof_max", 1500);
peixe_padrao("esvazia", 0.8);      // quanto a barra de pesca esvazia por frame
peixe_padrao("clique", 18);        // quanto cada clique enche a barra
peixe_padrao("fases", []);         // [] = aparece em todas as fases

// ---------- valores de jogo (derivados da ficha + fase atual) ----------
especie = especie_por_objeto(object_index);   // struct do catálogo (undefined se não cadastrado)
var _fase = fase_atual_dados();

being_caught = false;
parado = false;                 // true = não se move neste frame (pausa, transição ou fisgado)
cooldown_fisgar = 0;            // depois de escapar, o peixe fica "imune" por um tempo

fish_value = pontos;
difficulty_decay = esvazia * _fase.dif;
difficulty_gain = clique;
spd = velocidade * _fase.vel;
rotation_speed = 6;             // graus por frame
vel_x = 0;
vel_y = 0;
y_min = clamp(prof_min, MAR_Y_MIN, MAR_Y_MAX);
y_max = clamp(prof_max, MAR_Y_MIN, MAR_Y_MAX);

image_blend = cor;
image_xscale = escala;
image_yscale = escala;

// Cada comportamento redefine esta função (também é chamada ao escapar)
fish_init_movement = function() { };

escapar = function() {
    being_caught = false;
    cooldown_fisgar = 90;
    fish_init_movement();
};
