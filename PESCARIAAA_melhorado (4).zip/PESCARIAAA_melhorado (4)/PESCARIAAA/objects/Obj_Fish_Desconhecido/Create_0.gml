// ======================== FICHA DO PEIXE ========================
// Sprite = campo Sprite do objeto. Movimento = objeto PAI (Obj_Fish_Wander).
// Novo peixe? Duplique este objeto e cadastre em Scr_Catalogo (especies_cadastradas).
nome            = "???";
descricao       = "Não existe registro. Quem viu, preferiu não falar.";
curiosidade     = "Ele já estava te olhando antes de você jogar o anzol.";
raridade        = RARIDADE.LENDARIO;   // COMUM, INCOMUM, RARO ou LENDARIO
pontos          = 300;
velocidade      = 1.4;
escala          = 2.2;
cor             = make_color_rgb(110, 40, 140);   // tinta do sprite (c_white = sem tinta)
prof_min        = 4300;
prof_max        = 4900;
esvazia         = 1.2;    // barra esvazia por frame
clique          = 12;     // cada clique enche a barra  (~6.0 cliques/s para empatar, na fase 1)
fases           = [6];
fuga_distancia  = 140;     // (opcional) a que distância do anzol ele começa a fugir
fuga_velocidade = 2.2;    // (opcional) multiplicador da velocidade ao fugir
// ================================================================

event_inherited();
