// ======================== FICHA DO PEIXE ========================
// Sprite = campo Sprite do objeto. Movimento = objeto PAI (Obj_Fish_bounce).
// Novo peixe? Duplique este objeto e cadastre em Scr_Catalogo (especies_cadastradas).
nome            = "Lula";
descricao       = "Dispara pela água em jatos e muda de direção sem aviso.";
curiosidade     = "Seus olhos enormes foram feitos para o escuro. Ela te vê melhor do que você a ela.";
raridade        = RARIDADE.INCOMUM;   // COMUM, INCOMUM, RARO ou LENDARIO
pontos          = 35;
velocidade      = 3.8;
escala          = 1.2;
cor             = make_color_rgb(200, 120, 170);   // tinta do sprite (c_white = sem tinta)
prof_min        = 1800;
prof_max        = 3600;
esvazia         = 1.1;    // barra esvazia por frame
clique          = 16;     // cada clique enche a barra  (~4.1 cliques/s para empatar, na fase 1)
fases           = [3, 4, 5];
// ================================================================

event_inherited();
