event_inherited();

fish_init_movement = function() {
    peixe_definir_direcao(random(360), spd);
};
fish_init_movement();
