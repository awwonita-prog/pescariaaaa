event_inherited();
if (parado) exit;

x += vel_x;
y += vel_y;
peixe_ricochetear();
peixe_orientar();
