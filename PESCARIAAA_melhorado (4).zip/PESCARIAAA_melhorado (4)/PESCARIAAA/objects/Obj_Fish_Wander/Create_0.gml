event_inherited();

// campos opcionais da ficha:
//   fuga_distancia  = a que distância do anzol ele começa a fugir
//   fuga_velocidade = multiplicador da velocidade ao fugir
peixe_padrao("fuga_distancia", 90);
peixe_padrao("fuga_velocidade", 2.3);

flee_distance = fuga_distancia;
flee_speed = spd * fuga_velocidade;
change_dir_timer = FPS * 2;

fish_init_movement = function() {
    peixe_definir_direcao(random(360), spd);
};
fish_init_movement();
