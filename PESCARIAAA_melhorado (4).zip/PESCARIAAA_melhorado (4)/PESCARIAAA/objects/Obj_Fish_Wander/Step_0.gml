event_inherited();
if (parado) exit;

if (instance_exists(Obj_Hook)) {
    var _dist = point_distance(x, y, Obj_Hook.x, Obj_Hook.y);

    if (_dist < flee_distance) {
        // foge do anzol
        peixe_definir_direcao(point_direction(Obj_Hook.x, Obj_Hook.y, x, y), flee_speed);
        change_dir_timer = FPS;
    } else {
        change_dir_timer--;
        if (change_dir_timer <= 0) {
            peixe_definir_direcao(random(360), spd);
            change_dir_timer = FPS * (1 + random(2));
        }
    }
}

x += vel_x;
y += vel_y;
peixe_ricochetear();
peixe_orientar();
