if (jogo_parado()) exit;
tempo += velocidade;
