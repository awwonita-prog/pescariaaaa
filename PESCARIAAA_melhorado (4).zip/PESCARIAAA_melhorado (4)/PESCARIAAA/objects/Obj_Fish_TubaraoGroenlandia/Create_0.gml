// ======================== FICHA DO PEIXE ========================
// Sprite = campo Sprite do objeto. Movimento = objeto PAI (Obj_Fish_Wander).
// Novo peixe? Duplique este objeto e cadastre em Scr_Catalogo (especies_cadastradas).
nome            = "Tubarão-da-Groenlândia";
descricao       = "Lentíssimo e pesadíssimo. Vive séculos nas águas geladas do fundo.";
curiosidade     = "Alguns têm mais de 400 anos. Já estavam aqui antes do porto e da cidade.";
raridade        = RARIDADE.LENDARIO;   // COMUM, INCOMUM, RARO ou LENDARIO
pontos          = 170;
velocidade      = 0.9;
escala          = 2.6;
cor             = make_color_rgb(90, 100, 110);   // tinta do sprite (c_white = sem tinta)
prof_min        = 3600;
prof_max        = 4800;
esvazia         = 0.9;    // barra esvazia por frame
clique          = 12;     // cada clique enche a barra  (~4.5 cliques/s para empatar, na fase 1)
fases           = [5];
fuga_distancia  = 40;     // (opcional) a que distância do anzol ele começa a fugir
fuga_velocidade = 1.2;    // (opcional) multiplicador da velocidade ao fugir
// ================================================================

event_inherited();
