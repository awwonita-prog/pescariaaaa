// ======================== FICHA DO PEIXE ========================
// Sprite = campo Sprite do objeto. Movimento = objeto PAI (Obj_Fish_Wander).
// Novo peixe? Duplique este objeto e cadastre em Scr_Catalogo (especies_cadastradas).
nome            = "Tubarão-duende";
descricao       = "Habitante do fundo com a mandíbula que salta para fora. Lento e esquisito.";
curiosidade     = "Parece algo que nunca devia ter sido encontrado.";
raridade        = RARIDADE.RARO;   // COMUM, INCOMUM, RARO ou LENDARIO
pontos          = 100;
velocidade      = 0.9;
escala          = 1.6;
cor             = make_color_rgb(240, 170, 190);   // tinta do sprite (c_white = sem tinta)
prof_min        = 3000;
prof_max        = 4400;
esvazia         = 1.1;    // barra esvazia por frame
clique          = 16;     // cada clique enche a barra  (~4.1 cliques/s para empatar, na fase 1)
fases           = [5];
fuga_distancia  = 60;     // (opcional) a que distância do anzol ele começa a fugir
fuga_velocidade = 1.5;    // (opcional) multiplicador da velocidade ao fugir
// ================================================================

event_inherited();
