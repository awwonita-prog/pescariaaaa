// ======================== FICHA DO PEIXE ========================
// Sprite = campo Sprite do objeto. Movimento = objeto PAI (Obj_Fish_bounce).
// Novo peixe? Duplique este objeto e cadastre em Scr_Catalogo (especies_cadastradas).
nome            = "Atum";
descricao       = "Nadador incansável, rápido e forte na briga. Nunca para de se mover.";
curiosidade     = "Passa a vida inteira em movimento. Dizem que está fugindo de algo.";
raridade        = RARIDADE.INCOMUM;   // COMUM, INCOMUM, RARO ou LENDARIO
pontos          = 28;
velocidade      = 4.2;
escala          = 1.3;
cor             = make_color_rgb(70, 110, 170);   // tinta do sprite (c_white = sem tinta)
prof_min        = 900;
prof_max        = 2600;
esvazia         = 1.1;    // barra esvazia por frame
clique          = 17;     // cada clique enche a barra  (~3.9 cliques/s para empatar, na fase 1)
fases           = [2, 3, 4];
// ================================================================

event_inherited();
