// ======================== FICHA DO PEIXE ========================
// Sprite = campo Sprite do objeto. Movimento = objeto PAI (Obj_Fish_Wander).
// Novo peixe? Duplique este objeto e cadastre em Scr_Catalogo (especies_cadastradas).
nome            = "Marlin azul";
descricao       = "Velocíssimo e arisco. Foge do anzol e luta como poucos.";
curiosidade     = "O bico serve para atordoar presas. Já atravessou casco de barco.";
raridade        = RARIDADE.RARO;   // COMUM, INCOMUM, RARO ou LENDARIO
pontos          = 70;
velocidade      = 2.6;
escala          = 1.8;
cor             = make_color_rgb(60, 120, 230);   // tinta do sprite (c_white = sem tinta)
prof_min        = 400;
prof_max        = 2000;
esvazia         = 1.25;    // barra esvazia por frame
clique          = 15;     // cada clique enche a barra  (~5.0 cliques/s para empatar, na fase 1)
fases           = [3, 4, 5];
fuga_distancia  = 150;     // (opcional) a que distância do anzol ele começa a fugir
fuga_velocidade = 2.4;    // (opcional) multiplicador da velocidade ao fugir
// ================================================================

event_inherited();
