// ======================== FICHA DO PEIXE ========================
// Sprite = campo Sprite do objeto. Movimento = objeto PAI (Obj_Fish_Wander).
// Novo peixe? Duplique este objeto e cadastre em Scr_Catalogo (especies_cadastradas).
nome            = "Peixe-gato";
descricao       = "Pachorrento, vive perto do fundo e quase não liga para o anzol.";
curiosidade     = "Os bigodes sentem tudo na água. Até quem observa de baixo.";
raridade        = RARIDADE.COMUM;   // COMUM, INCOMUM, RARO ou LENDARIO
pontos          = 12;
velocidade      = 1.2;
escala          = 1.1;
cor             = make_color_rgb(150, 130, 100);   // tinta do sprite (c_white = sem tinta)
prof_min        = 500;
prof_max        = 1800;
esvazia         = 0.8;    // barra esvazia por frame
clique          = 20;     // cada clique enche a barra  (~2.4 cliques/s para empatar, na fase 1)
fases           = [1, 2, 3];
fuga_distancia  = 60;     // (opcional) a que distância do anzol ele começa a fugir
fuga_velocidade = 1.5;    // (opcional) multiplicador da velocidade ao fugir
// ================================================================

event_inherited();
