tempo++;

switch (estado) {
    case TRANS.ENCHENDO:
        nivel = min(1, nivel + 1 / 38);
        if (nivel >= 1) {
            estado = TRANS.SEGURANDO;
            cont = 0;
            espera = (titulo == "" && sub == "") ? 6 : 85;
            room_goto(alvo);   // se alvo for a room atual, ela é reiniciada
        }
        break;

    case TRANS.SEGURANDO:
        cont++;
        if (cont >= espera) estado = TRANS.ESVAZIANDO;
        break;

    case TRANS.ESVAZIANDO:
        nivel = max(0, nivel - 1 / 38);
        if (nivel <= 0) estado = TRANS.OCIOSA;
        break;
}
