if (nivel <= 0) exit;

// "Água" preta com a borda ondulada (mesmo visual da água do barco)
var _topo = GUI_H - nivel * (GUI_H + 80);
var _passo = 34;

draw_primitive_begin(pr_trianglestrip);
for (var xx = 0; xx <= GUI_W + _passo; xx += _passo) {
    var _yy = _topo + sin(tempo * 0.12 + xx * 0.018) * 14;
    draw_vertex_color(xx, _yy, c_black, 1);
    draw_vertex_color(xx, GUI_H + 40, c_black, 1);
}
draw_primitive_end();

for (var _o = 0; _o < 3; _o++) {
    draw_primitive_begin(pr_linestrip);
    for (var xx = 0; xx <= GUI_W + _passo; xx += _passo) {
        var _yy = _topo + sin(tempo * 0.12 + xx * 0.018) * 14 + _o;
        draw_vertex_color(xx, _yy, c_white, 1);
    }
    draw_primitive_end();
}

// Cartão de título: aparece quando a maré cobre quase tudo
var _a = clamp((nivel - 0.65) * 3, 0, 1);
if (_a > 0 && (titulo != "" || sub != "")) {
    draw_set_alpha(_a);
    ui_texto(GUI_W / 2, GUI_H / 2 - 40, titulo, c_white, 4, fa_center, fa_middle);
    ui_texto(GUI_W / 2, GUI_H / 2 + 40, sub, c_gray, 1.8, fa_center, fa_middle);
    draw_set_alpha(1);
}
