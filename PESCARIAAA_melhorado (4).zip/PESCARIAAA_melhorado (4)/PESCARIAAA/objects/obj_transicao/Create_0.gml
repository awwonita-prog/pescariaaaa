// Transição de fase: maré preta que sobe, mostra o título e desce.
estado = TRANS.OCIOSA;
nivel = 0;        // 0 = tela livre, 1 = tela toda coberta
tempo = 0;        // anima a onda
cont = 0;         // contador do estado "segurando"
espera = 85;      // quantos frames o cartão fica na tela
alvo = room;
titulo = "";
sub = "";

iniciar = function(_sala, _titulo, _sub) {
    estado = TRANS.ENCHENDO;
    alvo = _sala;
    titulo = _titulo;
    sub = _sub;
    cont = 0;
};
