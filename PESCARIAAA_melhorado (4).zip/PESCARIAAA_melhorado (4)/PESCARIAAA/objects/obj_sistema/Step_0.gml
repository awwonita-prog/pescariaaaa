if (keyboard_check_pressed(vk_f11)) tela_cheia_alternar();

// Fora das rooms de jogo (menu, catálogo) a pausa não existe.
if (!sala_de_jogo()) {
    menu_atual = undefined;
    if (!catalogo_aberto()) global.pausado = false;
    exit;
}

if (transicao_bloqueia() || catalogo_aberto()) exit;

// global.ignorar_teclas evita que o ESC/TAB que fechou o catálogo
// seja lido de novo aqui no mesmo frame.
var _esc = keyboard_check_pressed(vk_escape) && !global.ignorar_teclas;
var _tab = keyboard_check_pressed(vk_tab) && !global.ignorar_teclas;
global.ignorar_teclas = false;

if (!global.pausado) {
    if (!global.sem_pausa) {
        if (_esc) pausa_abrir();
        else if (_tab) catalogo_abrir_overlay();
    }
    exit;
}

// ---- jogo pausado ----
if (menu_atual == undefined) menu_atual = menu_pausa_criar();

if (_esc) {
    if (submenu == "opcoes") {
        submenu = "pausa";
        menu_atual = menu_pausa_criar();
        save_gravar();
    } else {
        pausa_fechar();
    }
    exit;
}

var _ev = menu_atual.atualizar();

if (submenu == "pausa") {
    switch (_ev) {
        case "continuar":
            pausa_fechar();
            break;
        case "catalogo":
            catalogo_abrir_overlay();
            break;
        case "opcoes":
            submenu = "opcoes";
            menu_atual = menu_opcoes_criar(GUI_W / 2, 330);
            break;
        case "menu":
            global.pausado = false;
            menu_atual = undefined;
            save_gravar();
            transicao_para(MenuInicial, "", "");
            break;
    }
} else {
    menu_opcoes_processar(menu_atual, _ev);
    if (_ev == "voltar") {
        submenu = "pausa";
        menu_atual = menu_pausa_criar();
        save_gravar();
    }
}
