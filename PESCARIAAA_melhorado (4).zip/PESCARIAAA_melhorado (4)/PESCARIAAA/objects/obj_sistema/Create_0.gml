// Objeto global (persistente): pausa, F11 e atalho do catálogo.
jogo_garantir_init();

// Se já existe um (veio de outra room), este é duplicado e some.
if (instance_number(obj_sistema) > 1) {
    instance_destroy();
    exit;
}

submenu = "pausa";      // "pausa" ou "opcoes"
menu_atual = undefined;

pausa_abrir = function() {
    global.pausado = true;
    submenu = "pausa";
    menu_atual = menu_pausa_criar();
};

pausa_fechar = function() {
    global.pausado = false;
    menu_atual = undefined;
    save_gravar();
};
