if (!global.pausado || menu_atual == undefined || !sala_de_jogo() || catalogo_aberto()) exit;

// escurece o jogo
draw_set_color(c_black);
draw_set_alpha(0.7);
draw_rectangle(0, 0, GUI_W, GUI_H, false);
draw_set_alpha(1);

ui_titulo(GUI_W / 2, 190, (submenu == "opcoes") ? "OPCOES" : "PAUSA", 1.4);
menu_atual.desenhar();

ui_texto(GUI_W / 2, GUI_H - 50, "W/S ou mouse: escolher   |   ENTER ou clique: confirmar   |   ESC: voltar", c_gray, 1.2, fa_center, fa_middle);
