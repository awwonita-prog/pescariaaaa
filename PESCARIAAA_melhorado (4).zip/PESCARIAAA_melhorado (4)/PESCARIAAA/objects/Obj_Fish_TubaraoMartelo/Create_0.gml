// ======================== FICHA DO PEIXE ========================
// Sprite = campo Sprite do objeto. Movimento = objeto PAI (Obj_Fish_Wander).
// Novo peixe? Duplique este objeto e cadastre em Scr_Catalogo (especies_cadastradas).
nome            = "Tubarão-martelo";
descricao       = "A cabeça larga ajuda a farejar e a enxergar de lado. Muito difícil de enganar.";
curiosidade     = "Os olhos nas pontas da cabeça veem quase tudo ao redor. Quase.";
raridade        = RARIDADE.RARO;   // COMUM, INCOMUM, RARO ou LENDARIO
pontos          = 85;
velocidade      = 2.2;
escala          = 1.9;
cor             = make_color_rgb(120, 140, 160);   // tinta do sprite (c_white = sem tinta)
prof_min        = 1500;
prof_max        = 3200;
esvazia         = 1.2;    // barra esvazia por frame
clique          = 15;     // cada clique enche a barra  (~4.8 cliques/s para empatar, na fase 1)
fases           = [4, 5];
fuga_distancia  = 100;     // (opcional) a que distância do anzol ele começa a fugir
fuga_velocidade = 2.0;    // (opcional) multiplicador da velocidade ao fugir
// ================================================================

event_inherited();
