spd = 0.1;      // suavização: quanto menor, mais o anzol "atrasa" em relação ao mouse
