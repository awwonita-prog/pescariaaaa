if (jogo_parado()) exit;

// segue o cursor com atraso
x = lerp(x, mouse_x, spd);
y = lerp(y, mouse_y, spd);

// só gira quando há distância (perto do cursor o ângulo ficava tremendo)
if (point_distance(x, y, mouse_x, mouse_y) > 4) {
    image_angle = point_direction(x, y, mouse_x, mouse_y);
}
