// ======================== FICHA DO PEIXE ========================
// Sprite = campo Sprite do objeto. Movimento = objeto PAI (Obj_Fish_Wander).
// Novo peixe? Duplique este objeto e cadastre em Scr_Catalogo (especies_cadastradas).
nome            = "Tubarão-limão";
descricao       = "Tubarão costeiro, calmo e curioso. O primeiro tubarão que você vai encarar.";
curiosidade     = "Gosta de águas rasas. As rasas daqui já não são tão seguras.";
raridade        = RARIDADE.INCOMUM;   // COMUM, INCOMUM, RARO ou LENDARIO
pontos          = 45;
velocidade      = 1.5;
escala          = 1.5;
cor             = make_color_rgb(200, 200, 90);   // tinta do sprite (c_white = sem tinta)
prof_min        = 700;
prof_max        = 2000;
esvazia         = 1.0;    // barra esvazia por frame
clique          = 17;     // cada clique enche a barra  (~3.5 cliques/s para empatar, na fase 1)
fases           = [2, 3, 4];
fuga_distancia  = 90;     // (opcional) a que distância do anzol ele começa a fugir
fuga_velocidade = 2.0;    // (opcional) multiplicador da velocidade ao fugir
// ================================================================

event_inherited();
