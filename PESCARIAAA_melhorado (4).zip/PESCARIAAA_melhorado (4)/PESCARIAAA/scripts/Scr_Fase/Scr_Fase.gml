// =====================================================================
//  Scr_Fase
//  Dados das fases + sorteio/spawn dos peixes.
//
//  PARA AJUSTAR A DIFICULDADE: edite a tabela abaixo.
//    nome       - título mostrado na transição e no HUD
//    meta       - quantidade de peixes que precisa pescar para passar
//    max_vivos  - peixes nadando ao mesmo tempo
//    intervalo  - frames entre o surgimento de um peixe novo
//    (os peixes de cada fase são definidos na FICHA de cada peixe: variável "fases")
//    vel        - multiplicador de velocidade dos peixes
//    dif        - multiplicador do esvaziamento da barra de pesca
//    escuridao  - escuridão base da tela (0 a 1); aumenta com a profundidade
//    subtitulo  - (opcional) texto da transição no lugar de "pesque N peixes"
//
//  A ÚLTIMA fase da tabela é a final: ao cumprir a meta dela o jogo termina
//  com a notícia (final_noticia, no fim deste arquivo).
// =====================================================================

function fases_definir() {
    global.fases = [
        { nome: "Águas Rasas",     meta: 8, max_vivos: 10, intervalo: 45, vel: 1.00, dif: 1.00, escuridao: 0.00 },
        { nome: "Correnteza",      meta: 7, max_vivos: 8,  intervalo: 50, vel: 1.10, dif: 1.05, escuridao: 0.08 },
        { nome: "Mar Aberto",      meta: 5, max_vivos: 6,  intervalo: 60, vel: 1.15, dif: 1.10, escuridao: 0.15 },
        { nome: "Abismo",          meta: 4, max_vivos: 5,  intervalo: 70, vel: 1.20, dif: 1.15, escuridao: 0.22 },
        { nome: "Fundo Sem Luz",   meta: 3, max_vivos: 3,  intervalo: 80, vel: 1.25, dif: 1.20, escuridao: 0.30 },
        { nome: "Onde Ele Espera", meta: 1, max_vivos: 1,  intervalo: 60, vel: 1.30, dif: 1.25, escuridao: 0.38,
          subtitulo: "Só resta um. Ele está esperando por você." }
    ];
}

function fase_total() {
    return array_length(global.fases);
}

function fase_obter(_indice) {
    return global.fases[clamp(_indice, 0, array_length(global.fases) - 1)];
}

function fase_atual_dados() {
    return fase_obter(global.fase_atual);
}

/// @desc Lista de espécies que podem aparecer na fase (índice 0-based).
///       Vem da variável "fases" da ficha de cada peixe ([] = todas as fases).
function fase_pool(_indice) {
    var _pool = [];
    var _numero = _indice + 1;
    for (var i = 0; i < array_length(global.especies); i++) {
        var _e = global.especies[i];
        if (array_length(_e.fases) == 0 || array_contains(_e.fases, _numero)) array_push(_pool, _e);
    }
    if (array_length(_pool) == 0) {
        show_debug_message("AVISO: nenhum peixe tem a fase " + string(_numero) + " na ficha. Usando todos.");
        return global.especies;
    }
    return _pool;
}

/// @desc Sorteia uma espécie da fase atual, respeitando a raridade.
function fase_escolher_especie() {
    var _pool = fase_pool(global.fase_atual);
    var _total = 0;
    for (var i = 0; i < array_length(_pool); i++) _total += especie_peso(_pool[i].raridade);

    var _sorteio = random(_total);
    var _acum = 0;
    for (var i = 0; i < array_length(_pool); i++) {
        _acum += especie_peso(_pool[i].raridade);
        if (_sorteio <= _acum) return _pool[i];
    }
    return _pool[0];
}

/// @desc Cria um peixe da fase atual, de preferência fora da área visível.
function fase_spawnar_peixe() {
    var _e = fase_escolher_especie();
    var _cam_y = camera_get_view_y(view_camera[0]);
    var _px = random_range(80, room_width - 80);
    var _py = random_range(_e.prof_min, _e.prof_max);
    var _tentativas = 0;
    while (_tentativas < 6 && _py > _cam_y - 100 && _py < _cam_y + GUI_H + 100) {
        _py = random_range(_e.prof_min, _e.prof_max);
        _tentativas++;
    }
    return instance_create_layer(_px, _py, "Peixes", _e.objeto);
}

/// @desc Vai para a fase _indice com a tela de transição (usa a room Mar).
function transicao_para_fase(_indice) {
    var _f = fase_obter(_indice);
    var _sub = _f.nome + " - pesque " + string(_f.meta) + ((_f.meta == 1) ? " peixe" : " peixes");
    if (variable_struct_exists(_f, "subtitulo")) _sub = _f.nome + " - " + _f.subtitulo;
    transicao_para(Mar, "FASE " + string(_indice + 1), _sub);
}

/// @desc Texto do final (tela preta), uma linha por item. "" = linha em branco.
///       O 1º item é o nome do jornal, o 2º é a manchete. Edite à vontade:
///       use linhas curtas (até ~75 caracteres), pois não há quebra automática.
function final_noticia() {
    return [
        "JORNAL DO LITORAL",
        "BARCO DE PESCA É ENCONTRADO À DERIVA, SEM TRIPULANTE",
        "",
        "A Capitania dos Portos informou que uma pequena embarcação de pesca",
        "foi localizada a 40 milhas da costa, com o motor desligado e o convés vazio.",
        "O equipamento estava intacto. Uma vara seguia presa ao anzol,",
        "com a linha esticada para dentro da água.",
        "",
        "O pescador não foi encontrado. A família conta que ele saiu para um dia",
        "de pesca e prometeu voltar para o jantar.",
        "",
        "As buscas foram encerradas após cinco dias. Pescadores da região",
        "dizem que, na noite do desaparecimento, o mar estava completamente calmo.",
        "Calmo demais."
    ];
}
