// =====================================================================
//  Scr_Fullscreen
//  Antes: window_set_fullscreen(true) solto no script (sem como desligar).
//  Agora: funções chamadas pelas Opções do menu e pela tecla F11.
// =====================================================================

/// @desc Liga/desliga tela cheia e guarda a escolha.
function tela_cheia_aplicar(_ativa) {
    global.tela_cheia = _ativa;
    window_set_fullscreen(_ativa);
}

/// @desc Alterna a tela cheia (F11) e salva a preferência.
function tela_cheia_alternar() {
    tela_cheia_aplicar(!global.tela_cheia);
    save_gravar();
}
