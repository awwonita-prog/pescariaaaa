// =====================================================================
//  Scr_UI
//  Ferramentas de interface (tudo desenhado na camada GUI, que não
//  sofre os efeitos de posterização/pixelização das rooms).
//    - ui_texto / ui_painel / ui_barra / ui_sprite_centrado
//    - MenuLista: menu reutilizável (teclado + mouse), usado no menu
//      principal, na pausa e nas opções.
//  O MenuLista NÃO usa callbacks: atualizar() devolve o "cod" do item
//  ativado e quem chamou decide o que fazer (evita problemas de escopo).
// =====================================================================

/// @desc Texto com sombra. Usa o alpha atual de draw_set_alpha.
function ui_texto(_x, _y, _txt, _cor = c_white, _escala = 1, _h = fa_left, _v = fa_top) {
    draw_set_halign(_h);
    draw_set_valign(_v);
    var _a = draw_get_alpha();
    draw_text_transformed_color(_x + 2, _y + 2, _txt, _escala, _escala, 0, c_black, c_black, c_black, c_black, _a);
    draw_text_transformed_color(_x, _y, _txt, _escala, _escala, 0, _cor, _cor, _cor, _cor, _a);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
}

/// @desc Texto com quebra de linha automática (largura em pixels).
function ui_texto_quebra(_x, _y, _txt, _cor, _escala, _largura) {
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    var _a = draw_get_alpha();
    draw_text_ext_transformed_color(_x + 2, _y + 2, _txt, -1, _largura / _escala, _escala, _escala, 0, c_black, c_black, c_black, c_black, _a);
    draw_text_ext_transformed_color(_x, _y, _txt, -1, _largura / _escala, _escala, _escala, 0, _cor, _cor, _cor, _cor, _a);
}

/// @desc Título com a fonte do jogo (só aceita letras maiúsculas e espaço).
function ui_titulo(_x, _y, _txt, _escala = 1) {
    if (global.fonte_titulo != -1) {
        draw_set_font(global.fonte_titulo);
    } else {
        _escala *= 3;   // sem a fonte, aumenta a fonte padrão
    }
    ui_texto(_x, _y, _txt, c_white, _escala, fa_center, fa_middle);
    draw_set_font(-1);
}

function ui_painel(_x1, _y1, _x2, _y2, _alpha = 0.7) {
    draw_set_color(c_black);
    draw_set_alpha(_alpha);
    draw_rectangle(_x1, _y1, _x2, _y2, false);
    draw_set_alpha(1);
    draw_set_color(c_white);
    draw_rectangle(_x1, _y1, _x2, _y2, true);
}

/// @desc Barra de progresso (pct de 0 a 1).
function ui_barra(_x, _y, _w, _h, _pct, _cor = c_white) {
    draw_set_color(c_dkgray);
    draw_rectangle(_x, _y, _x + _w, _y + _h, false);
    draw_set_color(_cor);
    draw_rectangle(_x, _y, _x + _w * clamp(_pct, 0, 1), _y + _h, false);
    draw_set_color(c_white);
    draw_rectangle(_x, _y, _x + _w, _y + _h, true);
}

/// @desc Desenha um sprite centrado em (cx, cy), seja qual for a origem dele.
function ui_sprite_centrado(_spr, _idx, _cx, _cy, _escala, _cor = c_white, _alpha = 1) {
    var _dx = (sprite_get_xoffset(_spr) - sprite_get_width(_spr) / 2) * _escala;
    var _dy = (sprite_get_yoffset(_spr) - sprite_get_height(_spr) / 2) * _escala;
    draw_sprite_ext(_spr, _idx, _cx + _dx, _cy + _dy, _escala, _escala, 0, _cor, _alpha);
}

// ---------------------------------------------------------------------
//  MenuLista
//  itens: array de structs { cod, texto, tipo, valor }
//    tipo "botao"    -> confirmar devolve cod
//    tipo "alternar" -> inverte valor (bool) e devolve cod
//    tipo "slider"   -> valor 0..1, setas/clique mudam de 0.1 em 0.1
// ---------------------------------------------------------------------
function MenuLista(_itens, _x, _y, _espaco = 60) constructor {
    itens = _itens;
    x = _x;
    y = _y;
    espaco = _espaco;
    largura = 560;
    selecionado = 0;
    bloqueio = 2;     // ignora entrada nos primeiros frames (evita clique "herdado")
    mx_ant = -1;
    my_ant = -1;

    /// @desc Valor atual de um item (alternar/slider) pelo cod.
    obter = function(_cod) {
        for (var i = 0; i < array_length(itens); i++) {
            if (itens[i].cod == _cod) return itens[i].valor;
        }
        return undefined;
    };

    /// @desc Processa a entrada. Devolve o cod do item ativado ou "".
    atualizar = function() {
        if (bloqueio > 0) {
            bloqueio--;
            return "";
        }
        var _n = array_length(itens);
        var _evento = "";

        if (keyboard_check_pressed(vk_down) || keyboard_check_pressed(ord("S"))) selecionado = (selecionado + 1) mod _n;
        if (keyboard_check_pressed(vk_up) || keyboard_check_pressed(ord("W"))) selecionado = (selecionado - 1 + _n) mod _n;

        var _mx = device_mouse_x_to_gui(0);
        var _my = device_mouse_y_to_gui(0);
        var _sobre = -1;
        for (var i = 0; i < _n; i++) {
            var _iy = y + espaco * i;
            if (point_in_rectangle(_mx, _my, x - largura / 2, _iy - espaco / 2, x + largura / 2, _iy + espaco / 2)) _sobre = i;
        }
        if (_sobre >= 0 && (_mx != mx_ant || _my != my_ant)) selecionado = _sobre;
        mx_ant = _mx;
        my_ant = _my;

        var _clique = (mouse_check_button_pressed(mb_left) && _sobre >= 0);
        if (_clique) selecionado = _sobre;
        var _confirmar = keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space);

        var _dir = 0;
        if (keyboard_check_pressed(vk_right) || keyboard_check_pressed(ord("D"))) _dir = 1;
        if (keyboard_check_pressed(vk_left) || keyboard_check_pressed(ord("A"))) _dir = -1;

        var _item = itens[selecionado];
        switch (_item.tipo) {
            case "botao":
                if (_confirmar || _clique) _evento = _item.cod;
                break;
            case "alternar":
                if (_confirmar || _clique || _dir != 0) {
                    _item.valor = !_item.valor;
                    _evento = _item.cod;
                }
                break;
            case "slider":
                if (_clique) _dir = (_mx >= x) ? 1 : -1;
                if (_dir != 0) {
                    _item.valor = clamp(round((_item.valor + 0.1 * _dir) * 10) / 10, 0, 1);
                    _evento = _item.cod;
                }
                break;
        }
        return _evento;
    };

    desenhar = function() {
        for (var i = 0; i < array_length(itens); i++) {
            var _it = itens[i];
            var _iy = y + espaco * i;
            var _sel = (i == selecionado);
            var _txt = _it.texto;
            if (_it.tipo == "alternar") _txt += ": " + (_it.valor ? "SIM" : "NÃO");
            if (_it.tipo == "slider") _txt += ": " + string(round(_it.valor * 100)) + "%";
            if (_sel) {
                draw_set_color(c_white);
                draw_set_alpha(0.22);
                draw_rectangle(x - largura / 2, _iy - espaco / 2 + 4, x + largura / 2, _iy + espaco / 2 - 4, false);
                draw_set_alpha(1);
                _txt = (_it.tipo == "slider") ? ("<  " + _txt + "  >") : ("> " + _txt + " <");
            }
            ui_texto(x, _iy, _txt, _sel ? c_white : c_gray, 2, fa_center, fa_middle);
        }
        draw_set_color(c_white);
    };
}

// ---------------------------------------------------------------------
//  Menus prontos
// ---------------------------------------------------------------------
function menu_principal_criar() {
    return new MenuLista([
        { cod: "jogar",    texto: "Jogar",    tipo: "botao" },
        { cod: "catalogo", texto: "Catálogo", tipo: "botao" },
        { cod: "opcoes",   texto: "Opções",   tipo: "botao" },
        { cod: "sair",     texto: "Sair",     tipo: "botao" }
    ], GUI_W / 2, 360);
}

function menu_pausa_criar() {
    return new MenuLista([
        { cod: "continuar", texto: "Continuar",          tipo: "botao" },
        { cod: "catalogo",  texto: "Catálogo de peixes", tipo: "botao" },
        { cod: "opcoes",    texto: "Opções",             tipo: "botao" },
        { cod: "menu",      texto: "Voltar ao menu",     tipo: "botao" }
    ], GUI_W / 2, 330);
}

function menu_opcoes_criar(_x, _y) {
    return new MenuLista([
        { cod: "tela_cheia", texto: "Tela cheia", tipo: "alternar", valor: global.tela_cheia },
        { cod: "volume",     texto: "Volume",     tipo: "slider",   valor: global.volume },
        { cod: "voltar",     texto: "Voltar",     tipo: "botao" }
    ], _x, _y);
}

/// @desc Aplica o efeito dos itens do menu de opções.
function menu_opcoes_processar(_menu, _evento) {
    switch (_evento) {
        case "tela_cheia":
            tela_cheia_aplicar(_menu.obter("tela_cheia"));
            break;
        case "volume":
            global.volume = _menu.obter("volume");
            audio_master_gain(global.volume);
            break;
    }
}
