// =====================================================================
//  Scr_Peixe
//  Funções compartilhadas pelos comportamentos de peixe.
//  Devem ser chamadas DENTRO de um objeto filho de Obj_Fish
//  (usam vel_x, vel_y, y_min, y_max, escala, rotation_speed).
// =====================================================================

/// @desc Define a velocidade a partir de uma direção (graus) e uma velocidade.
function peixe_definir_direcao(_direcao, _velocidade) {
    vel_x = lengthdir_x(_velocidade, _direcao);
    vel_y = lengthdir_y(_velocidade, _direcao);
}

/// @desc Ricocheteia nas bordas do mar e na faixa de profundidade da espécie.
///       Só inverte a velocidade se o peixe estiver INDO em direção à borda
///       (evita o peixe ficar "tremendo" preso na parede).
function peixe_ricochetear() {
    if ((x <= 0 && vel_x < 0) || (x >= room_width && vel_x > 0)) vel_x = -vel_x;
    if ((y <= y_min && vel_y < 0) || (y >= y_max && vel_y > 0)) vel_y = -vel_y;
    x = clamp(x, 0, room_width);
    y = clamp(y, y_min, y_max);
}

/// @desc Gira o sprite suavemente para a direção do movimento e desvira o
///       peixe quando ele nada para a esquerda (antes ficava de cabeça para baixo).
function peixe_orientar() {
    var _alvo = point_direction(0, 0, vel_x, vel_y);
    image_angle += clamp(angle_difference(_alvo, image_angle), -rotation_speed, rotation_speed);
    image_xscale = escala;
    image_yscale = (lengthdir_x(1, image_angle) < 0) ? -escala : escala;
}

/// @desc Se a variável ainda não existe no peixe, cria com o valor padrão.
///       É assim que a ficha do peixe pode omitir campos opcionais
///       (e também funciona com Variable Definitions do objeto).
function peixe_padrao(_nome_var, _valor) {
    if (!variable_instance_exists(id, _nome_var)) variable_instance_set(id, _nome_var, _valor);
}
