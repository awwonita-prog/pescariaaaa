// =====================================================================
//  Scr_Save
//  Salva/carrega opções, recorde e catálogo em "pescaria.ini".
//  O catálogo é salvo pelo NOME DO OBJETO do peixe (ex.: Obj_Fish_3);
//  se você renomear um objeto de peixe, o progresso dele no catálogo é zerado.
// =====================================================================

function save_gravar() {
    ini_open(SAVE_FILE);
    ini_write_real("opcoes", "tela_cheia", global.tela_cheia ? 1 : 0);
    ini_write_real("opcoes", "volume", global.volume);
    ini_write_real("progresso", "melhor_pontos", global.melhor_pontos);
    ini_write_real("progresso", "fase_maxima", global.fase_maxima);
    for (var i = 0; i < array_length(global.especies); i++) {
        var _e = global.especies[i];
        ini_write_real("catalogo", _e.chave, _e.capturas);
    }
    ini_close();
}

function save_carregar() {
    ini_open(SAVE_FILE);
    global.tela_cheia = (ini_read_real("opcoes", "tela_cheia", 1) == 1);
    global.volume = clamp(ini_read_real("opcoes", "volume", 1), 0, 1);
    global.melhor_pontos = ini_read_real("progresso", "melhor_pontos", 0);
    global.fase_maxima = ini_read_real("progresso", "fase_maxima", 0);
    for (var i = 0; i < array_length(global.especies); i++) {
        var _e = global.especies[i];
        _e.capturas = ini_read_real("catalogo", _e.chave, 0);
        _e.descoberto = (_e.capturas > 0);
    }
    ini_close();
}

/// @desc Apaga o progresso (catálogo e recorde). Útil para testes.
function save_apagar() {
    file_delete(SAVE_FILE);
    for (var i = 0; i < array_length(global.especies); i++) {
        global.especies[i].capturas = 0;
        global.especies[i].descoberto = false;
    }
    global.melhor_pontos = 0;
    global.fase_maxima = 0;
}
