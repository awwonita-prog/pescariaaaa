// =====================================================================
//  Scr_Catalogo
//
//  COMO CRIAR UM PEIXE NOVO (3 passos):
//    1) No GameMaker, DUPLIQUE um objeto da pasta FishTypes (ex.: Obj_Fish_Atum)
//       e dê um nome novo (ex.: Obj_Fish_Pirarucu).
//    2) No objeto novo:
//         - troque o SPRITE (campo Sprite do objeto);
//         - troque o PAI (campo Parent) = tipo de movimento:
//              Obj_Fish_bounce   -> ricocheteia pelo mar
//              Obj_Fish_Straight -> vai e volta em linha reta
//              Obj_Fish_Wander   -> vaga e foge do anzol
//         - edite a FICHA DO PEIXE no evento Create (nome, pontos, fases...).
//    3) Escreva o nome do objeto na lista abaixo (especies_cadastradas).
//
//  Pronto: o peixe passa a aparecer no mar (nas fases da ficha) e no catálogo.
//  A lista abaixo também define a ORDEM em que eles aparecem no catálogo.
// =====================================================================

function especies_cadastradas() {
    return [
        Obj_Fish_Salmao,             // Salmão
        Obj_Fish_PeixeGato,          // Peixe-gato
        Obj_Fish_PeixeLeao,          // Peixe-leão
        Obj_Fish_Atum,               // Atum
        Obj_Fish_TubaraoLimao,       // Tubarão-limão
        Obj_Fish_Lula,               // Lula
        Obj_Fish_MarlinAzul,         // Marlin azul
        Obj_Fish_TubaraoTigre,       // Tubarão-tigre
        Obj_Fish_TubaraoMartelo,     // Tubarão-martelo
        Obj_Fish_TubaraoDuende,      // Tubarão-duende
        Obj_Fish_TubaraoBranco,      // Tubarão-branco
        Obj_Fish_TubaraoGroenlandia, // Tubarão-da-Groenlândia
        Obj_Fish_Desconhecido        // ???
        // <<< novos peixes: acrescente aqui (lembre da vírgula na linha de cima)
    ];
}

// ---------------------------------------------------------------------
//  Monta global.especies lendo a ficha de cada objeto cadastrado.
//  Cria uma instância temporária fora da tela só para ler as variáveis.
// ---------------------------------------------------------------------
function especies_definir() {
    global.especies = [];   // vazio de propósito: o Create dos peixes consulta esta lista

    var _lista = especies_cadastradas();
    for (var i = 0; i < array_length(_lista); i++) {
        var _obj = _lista[i];
        var _f = instance_create_depth(-10000, -10000, 0, _obj);

        array_push(global.especies, {
            objeto: _obj,
            chave: object_get_name(_obj),      // usada no arquivo de save
            nome: _f.nome,
            descricao: _f.descricao,
            curiosidade: _f.curiosidade,
            raridade: _f.raridade,
            pontos: _f.pontos,
            escala: _f.escala,
            cor: _f.cor,
            sprite: _f.sprite_index,           // vem do campo Sprite do objeto
            prof_min: _f.prof_min,
            prof_max: _f.prof_max,
            fases: _f.fases,
            descoberto: false,
            capturas: 0
        });

        instance_destroy(_f);
    }
}

/// @desc Struct da espécie a partir do objeto (ou undefined se não cadastrado).
function especie_por_objeto(_obj) {
    for (var i = 0; i < array_length(global.especies); i++) {
        if (global.especies[i].objeto == _obj) return global.especies[i];
    }
    return undefined;
}

/// @desc Peso de sorteio por raridade (comum aparece mais).
function especie_peso(_raridade) {
    switch (_raridade) {
        case RARIDADE.COMUM:    return 10;
        case RARIDADE.INCOMUM:  return 6;
        case RARIDADE.RARO:     return 3;
        case RARIDADE.LENDARIO: return 1;
    }
    return 1;
}

function raridade_nome(_raridade) {
    switch (_raridade) {
        case RARIDADE.COMUM:    return "Comum";
        case RARIDADE.INCOMUM:  return "Incomum";
        case RARIDADE.RARO:     return "Raro";
        case RARIDADE.LENDARIO: return "Lendário";
    }
    return "?";
}

function raridade_cor(_raridade) {
    switch (_raridade) {
        case RARIDADE.COMUM:    return c_ltgray;
        case RARIDADE.INCOMUM:  return make_color_rgb(110, 210, 130);
        case RARIDADE.RARO:     return make_color_rgb(90, 170, 255);
        case RARIDADE.LENDARIO: return make_color_rgb(255, 80, 80);
    }
    return c_white;
}

/// @desc Registra a captura (e descobre a espécie na primeira vez).
/// @arg _esp  struct da espécie (instância.especie)
function catalogo_registrar_captura(_esp) {
    _esp.capturas += 1;
    _esp.descoberto = true;
}

function catalogo_total() {
    return array_length(global.especies);
}

function catalogo_total_descobertos() {
    var _n = 0;
    for (var i = 0; i < array_length(global.especies); i++) {
        if (global.especies[i].descoberto) _n++;
    }
    return _n;
}

/// @desc Abre o catálogo como tela por cima do jogo (tecla TAB ou menu de pausa).
function catalogo_abrir_overlay() {
    if (!instance_exists(Obj_menu_catalogo)) instance_create_depth(0, 0, -15000, Obj_menu_catalogo);
}

function catalogo_aberto() {
    return instance_exists(Obj_menu_catalogo);
}
