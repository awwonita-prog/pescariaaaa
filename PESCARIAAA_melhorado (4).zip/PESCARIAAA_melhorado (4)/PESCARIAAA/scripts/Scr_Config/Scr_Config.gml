// =====================================================================
//  Scr_Config
//  Constantes, enums e inicialização global do jogo.
//
//  REGRA DO PROJETO: scripts não têm código solto fora de funções.
//  Toda a inicialização passa por jogo_garantir_init(), que é chamada
//  no Create dos objetos "de entrada" (menu, jogador, controlador...).
//  Assim qualquer room pode ser testada isoladamente pelo GameMaker.
// =====================================================================

// ---------- Tela / interface ----------
#macro GUI_W 1366
#macro GUI_H 768
#macro FPS 60

// ---------- Mecânica de pesca ----------
#macro RAIO_FISGAR 90        // distância máxima anzol -> peixe para fisgar
#macro BARRA_MAX 100         // tamanho da barra de pesca
#macro BARRA_INICIAL 35      // quanto a barra já começa preenchida

// ---------- Mar ----------
#macro MAR_Y_MIN 100
#macro MAR_Y_MAX 4950

// ---------- Arquivos ----------
#macro SAVE_FILE "pescaria.ini"

enum RARIDADE { COMUM, INCOMUM, RARO, LENDARIO }
enum TRANS { OCIOSA, ENCHENDO, SEGURANDO, ESVAZIANDO }
enum FASE_ESTADO { JOGANDO, CONCLUIDA, TRANSICAO, FINAL }

/// @desc Inicializa todas as variáveis globais (só roda uma vez).
function jogo_garantir_init() {
    if (variable_global_exists("jogo_pronto")) return;
    global.jogo_pronto = true;

    // estado da partida
    global.pausado = false;
    global.sem_pausa = false;        // true = pausa bloqueada (fim de fase, vitória)
    global.ignorar_teclas = false;   // evita ESC/TAB "vazar" entre telas no mesmo frame
    global.fase_atual = 0;           // índice da fase (começa em 0)
    global.pontos = 0;
    global.peixes_total = 0;

    // progresso e opções (sobrescritos por save_carregar)
    global.melhor_pontos = 0;
    global.fase_maxima = 0;
    global.tela_cheia = true;
    global.volume = 1;

    // fonte do título (arquivo incluído em datafiles; só tem letras A-Z)
    global.fonte_titulo = -1;
    var _arq = working_directory + "Soccer League Training.ttf";
    if (file_exists(_arq)) global.fonte_titulo = font_add(_arq, 56, false, false, 32, 127);

    fases_definir();       // antes das espécies: o Create dos peixes usa os dados da fase
    especies_definir();
    save_carregar();

    display_set_gui_size(GUI_W, GUI_H);
    tela_cheia_aplicar(global.tela_cheia);
    audio_master_gain(global.volume);
}

/// @desc Começa uma partida nova (zera fase, pontos e estados de pausa).
function jogo_novo() {
    global.fase_atual = 0;
    global.pontos = 0;
    global.peixes_total = 0;
    global.pausado = false;
    global.sem_pausa = false;
}

/// @desc true quando o jogo deve "congelar" (pausa ou transição cobrindo a tela).
function jogo_parado() {
    return global.pausado || transicao_bloqueia();
}

/// @desc true nas rooms onde se joga de fato (onde a pausa funciona).
function sala_de_jogo() {
    return (room == Barco || room == Mar);
}

/// @desc Garante que o objeto global obj_sistema (pausa, F11) exista.
function sistema_garantir() {
    jogo_garantir_init();
    if (!instance_exists(obj_sistema)) instance_create_depth(0, 0, -15000, obj_sistema);
}
