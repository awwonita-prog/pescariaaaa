// =====================================================================
//  Scr_Transicao
//  API da transição de fase: uma "maré" preta sobe pela tela, mostra o
//  cartão de título enquanto troca de room e depois desce.
//  O trabalho visual fica no objeto obj_transicao.
// =====================================================================

/// @desc Troca de room com a animação de transição.
/// @arg _sala    room de destino (use a room atual para reiniciá-la)
/// @arg _titulo  texto grande (pode ser "")
/// @arg _sub     texto pequeno (pode ser "")
function transicao_para(_sala, _titulo = "", _sub = "") {
    sistema_garantir();
    if (!instance_exists(obj_transicao)) instance_create_depth(0, 0, -16000, obj_transicao);
    if (obj_transicao.estado == TRANS.OCIOSA) {
        with (obj_transicao) {
            iniciar(_sala, _titulo, _sub);
        }
    }
}

/// @desc true enquanto a tela está sendo coberta ou o cartão está na tela.
function transicao_bloqueia() {
    if (!instance_exists(obj_transicao)) return false;
    return (obj_transicao.estado == TRANS.ENCHENDO || obj_transicao.estado == TRANS.SEGURANDO);
}
