# PESCARIAAA – o que mudou

Abra `PESCARIAAA/PESCARIAAA.yyp` no GameMaker (o projeto original usava IDE 2026.0.0.16).
**Importante:** eu não tenho o GameMaker aqui, então não consegui rodar o jogo. Validei por análise estática
(JSON dos .yy, eventos x arquivos, balanceamento do GML, funções e assets referenciados). Se aparecer algum erro
ao compilar, me mande a mensagem que eu corrijo.

## Controles
| Ação | Tecla |
|---|---|
| Andar no barco | A / D ou setas |
| Pescar (perto da vara) | ESPAÇO |
| Mover o anzol | Mouse |
| Fisgar | Clique no peixe **com o anzol perto dele** |
| Puxar o peixe | Clicar rápido para encher a barra |
| Descer/subir no mar | Roda do mouse ou W/S |
| Catálogo | TAB |
| Pausa | ESC |
| Tela cheia | F11 |

## Fluxo do jogo
Menu inicial → Barco (ESPAÇO na vara) → Mar (fases 1 a 6) → final (notícia na tela preta) → menu.
Cada fase pede uma quantidade de peixes; ao atingir a meta, "FASE COMPLETA!" e a transição (maré preta que sobe
com o título da próxima fase). A fase 6 tem um único peixe, o "???": ao pescá-lo a tela escurece e aparece a notícia do barco desaparecido. Depois, ENTER volta ao menu.

## O que foi pedido
- **Menu inicial** (`Obj_Menu`): Jogar, Catálogo, Opções (tela cheia + volume), Sair. Teclado e mouse.
- **Menu de pausa** (`obj_sistema`): Continuar, Catálogo, Opções, Voltar ao menu. Congela peixes, câmera, anzol, corda e jogador.
- **Catálogo** (`Obj_menu_catalogo`): lê a ficha dos peixes cadastrados (13 peixes), grade com silhueta para as não descobertas, detalhes (raridade, pontos,
  profundidade, nº capturado, descrição e frase de terror), paginação e contador. Funciona como tela do menu e como overlay no jogo.
- **Fases com meta** (`Scr_Fase`): tabela com meta de peixes, quantidade simultânea, espécies, velocidade, dificuldade e escuridão.
- **Transição** (`obj_transicao`): maré preta com borda ondulada (mesmo visual da água) + cartão com o título.
- **Código estruturado**: dados em tabelas/fichas, sem código solto em scripts, sem números mágicos (macros em `Scr_Config`),
  funções por assunto (`Scr_UI`, `Scr_Peixe`, `Scr_Save`, `Scr_Transicao`...), menu reutilizável (`MenuLista`).

## Bugs corrigidos
1. O menu inicial não levava a lugar nenhum e o jogo abria direto no Barco → agora `MenuInicial` é a primeira room.
2. Objetos persistentes (`obj_game_controller`, `Obj_menu_catalogo`, `Obj_global`) eram recriados a cada entrada na room, duplicando HUD e lógica → controlador e catálogo não são mais persistentes; os globais têm guarda contra duplicata. `Obj_global` foi removido.
3. A barra de pesca começava em 0 e só não perdia na hora porque o clique que fisgava contava como ganho → agora começa em 35 e esse clique não conta.
4. Peixes viravam de cabeça para baixo ao nadar para a esquerda e giravam em torno dos "pés" (origem do sprite em baixo) → origem no centro e flip vertical correto.
5. Peixes ficavam "tremendo" presos na borda (a velocidade invertia mesmo já se afastando da parede); o peixe Straight podia ficar preso na parede → corrigido.
6. Dava para fisgar um peixe sem o anzol estar perto → agora exige `RAIO_FISGAR` (pode ajustar em `Scr_Config`).
7. Pontuação e descoberta ficavam no evento Destroy do peixe → movidas para o controlador (`peixe_capturar`).
8. Peixes Straight/Wander/bounce usados diretamente davam erro (sem `id_nome_peixe`) → tudo vem da tabela de espécies.
9. Debug de `hspd` desenhado em cima do jogador, `keyboard_set_map` global, `gpu_set_texfilter` vazando, 32 px por clique da roda (5000 px de mar = 150 cliques) → agora 120 px + W/S, variáveis mortas e `CleanUp` órfão removidos, GUI com tamanho fixo (1366x768), largura das rooms padronizada.

## As 6 fases
Quanto mais fundo, menos peixes (a meta e a quantidade simultânea diminuem a cada fase). A última tem só o "???".

| Fase | Nome | Meta | Simultâneos | Peixes que aparecem |
|---|---|---|---|---|
| 1 | Águas Rasas | 8 | 10 | Salmão, Peixe-gato |
| 2 | Correnteza | 7 | 8 | Salmão, Peixe-gato, Peixe-leão, Atum, Tubarão-limão |
| 3 | Mar Aberto | 5 | 6 | Peixe-gato, Peixe-leão, Atum, Tubarão-limão, Lula, Marlin azul |
| 4 | Abismo | 4 | 5 | Atum, Tubarão-limão, Lula, Marlin azul, Tubarão-tigre, Tubarão-martelo |
| 5 | Fundo Sem Luz | 3 | 3 | Lula, Marlin azul, Tubarão-tigre, Tubarão-martelo, Tubarão-duende, Tubarão-branco, Tubarão-da-Groenlândia |
| 6 | Onde Ele Espera | 1 | 1 | ??? |

Na fase 6 aparece uma seta ("mais fundo" / "mais acima") indicando onde olhar, porque o "???" fica no escuro lá no fundo.

## O final
Texto da notícia: função `final_noticia()` no fim de `Scr_Fase.gml`. Cada item do array é uma linha (o 1º é o nome do jornal,
o 2º a manchete, `""` é linha em branco). Não há quebra automática: mantenha as linhas com até ~75 caracteres.

## Os 13 peixes
Cada linha é um objeto em `FishTypes`. "Cliques/s" = ritmo mínimo para a barra não esvaziar (cresce um pouco a cada fase, pelo multiplicador `dif`).

| Peixe | Movimento | Raridade | Pontos | Fases | Cliques/s |
|---|---|---|---|---|---|
| Salmão | Straight (migra em linha reta) | Comum | 10 | 1-2 | ~3 |
| Peixe-gato | Wander lento, quase não foge | Comum | 12 | 1-3 | ~2,5 |
| Peixe-leão | Wander lento, não foge | Incomum | 22 | 2-3 | ~2,8 |
| Atum | Bounce rápido (nunca para) | Incomum | 28 | 2-4 | ~4,3 |
| Tubarão-limão | Wander calmo | Incomum | 45 | 2-4 | ~3,9 |
| Lula | Bounce com arrancadas | Incomum | 35 | 3-5 | ~4,7 |
| Marlin azul | Wander muito arisco e veloz | Raro | 70 | 3-5 | ~5,8 |
| Tubarão-tigre | Wander firme | Raro | 75 | 4-5 | ~5,4 |
| Tubarão-martelo | Wander, difícil de enganar | Raro | 85 | 4-5 | ~5,6 |
| Tubarão-duende | Wander lento, só no fundo | Raro | 100 | 5 | ~5,0 |
| Tubarão-branco | Wander, quase não foge | Lendário | 150 | 5 | ~6,5 |
| Tubarão-da-Groenlândia | Wander lentíssimo e pesado | Lendário | 170 | 5 | ~5,4 |
| ??? | Wander esquivo | Lendário | 300 | 6 (final) | ~7,5 |

Dica: o alcance para fisgar é `RAIO_FISGAR` (90) × `escala` do peixe (mínimo 90). Peixe grande é mais fácil de clicar;
`fuga_distancia` maior que esse alcance exige encurralar o peixe.

## Como criar um peixe novo (3 passos)
Cada espécie é um objeto na pasta **FishTypes**, como antes.
1. **Duplique** um objeto de peixe (ex.: `Obj_Fish_Atum`) e dê um nome novo (ex.: `Obj_Fish_Pirarucu`).
2. No objeto novo:
   - troque o **Sprite** (campo Sprite do objeto);
   - troque o **Parent** = tipo de movimento: `Obj_Fish_bounce` (ricocheteia), `Obj_Fish_Straight` (vai e volta em linha reta) ou `Obj_Fish_Wander` (vaga e foge do anzol);
   - edite a **ficha** no evento Create.
3. Escreva o nome do objeto na lista `especies_cadastradas()` em `Scr_Catalogo` (uma linha). Essa lista também define a ordem no catálogo.

### Ficha do peixe (Create do objeto, antes do `event_inherited()`)
| Campo | Para que serve |
|---|---|
| `nome`, `descricao`, `curiosidade` | textos do catálogo |
| `raridade` | `COMUM`, `INCOMUM`, `RARO`, `LENDARIO` (define a chance de aparecer e a cor no catálogo) |
| `pontos` | pontos ao pescar |
| `velocidade`, `escala`, `cor` | nado, tamanho e tinta do sprite |
| `prof_min`, `prof_max` | profundidade onde ele vive (pixels) |
| `esvazia`, `clique` | dificuldade: quanto a barra esvazia por frame / quanto cada clique enche |
| `fases` | fases em que aparece, ex.: `[2, 3, 4]` (`[]` = todas) |

Campos opcionais por tipo de movimento (se omitir, usa o padrão):
- `Obj_Fish_Straight`: `alcance` (pixels antes de voltar).
- `Obj_Fish_Wander`: `fuga_distancia` (a que distância do anzol foge) e `fuga_velocidade` (multiplicador ao fugir).

Qualquer campo omitido usa um valor padrão (definido no Create de `Obj_Fish`). Os campos também podem vir das
**Variable Definitions** do objeto em vez do código: o jogo lê dos dois jeitos.

## Como ajustar as fases
`fases_definir()` em `Scr_Fase`: meta de peixes, quantos ao mesmo tempo, velocidade, dificuldade e escuridão. A última fase da tabela é a final.
**Quais peixes aparecem em cada fase** é definido na ficha de cada peixe (campo `fases`).

- A "meta" da fase é por **quantidade de peixes**. Para virar meta por pontos, troque a condição em `peixe_capturar`
  (`obj_game_controller/Create_0.gml`).

## Salvamento
`pescaria.ini` guarda opções, melhor pontuação, fase mais distante e o catálogo (por **nome do objeto** do peixe: se renomear um objeto, o progresso dele no catálogo zera). Para zerar, apague o arquivo (ou use `save_apagar()`).

## Ideias que NÃO implementei (sugestões)
- Sons e música (o projeto não tem áudio; `audio_master_gain` já está ligado ao volume das Opções).
- Condição de derrota (tempo por fase, "sanidade" que cai no escuro, peixe que corta a linha).
- Sustos: olhos no fundo, flash quando um raro aparece, câmera tremendo com a barra quase vazia.
- Arte própria para cada espécie e fundos diferentes por fase.
- Continuar a partir da fase mais distante.
